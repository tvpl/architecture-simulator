# Lista de Bugs e Melhorias para o Simulador de Arquiteturas

## Bugs Identificados
1. **Edição de componentes após inserção**
   - Não é possível editar os componentes depois de inseridos no board
   - Prioridade: Alta

2. **Conexões entre componentes**
   - Não é possível ligar um componente no outro para gerar a arquitetura
   - Prioridade: Alta

3. **Botões de controle de simulação**
   - Os botões iniciar e reiniciar não funcionam corretamente
   - Prioridade: Alta

4. **Controles de configuração inadequados**
   - Os controles de instância, latência, etc. não fazem sentido para todos os componentes
   - Prioridade: Média

5. **Dicas persistentes**
   - As dicas não podem ser fechadas para ganhar espaço na tela
   - Prioridade: Média

## Melhorias Solicitadas
1. **Suporte a protocolos adicionais**
   - Adicionar suporte para HTTP e gRPC além da mensageria
   - Prioridade: Alta

2. **Interface mais clean**
   - Deixar os controles mais clean e ampliar a tela de desenho
   - Prioridade: Média

3. **Cálculo de custo**
   - Permitir definir o custo de cada componente e por instância
   - Calcular o custo total da arquitetura
   - Prioridade: Alta

## Plano de Correção e Implementação

### Fase 1: Correções Críticas
- Corrigir a edição de componentes após inserção
- Corrigir a funcionalidade de conexão entre componentes
- Consertar os botões de iniciar e reiniciar

### Fase 2: Novas Funcionalidades
- Implementar suporte para HTTP e gRPC
- Adicionar cálculo de custo por componente e por instância
- Adaptar controles para fazer sentido por tipo de componente

### Fase 3: Melhorias de Interface
- Permitir fechar dicas para ganhar espaço
- Redesenhar controles para layout mais clean
- Ampliar a área de desenho da solução

### Fase 4: Validação e Entrega
- Testar todas as correções e novas funcionalidades
- Validar a experiência do usuário
- Entregar versão corrigida
