# Correção do Simulador de Arquitetura

## Problema Identificado

Ao executar o Simulador de Arquitetura, foram encontrados os seguintes erros no console:

```
Uncaught TypeError: onRequestCountChange is not a function
    at index.tsx:99:7
```

```
Uncaught TypeError: onStart is not a function
    at index.tsx:60:5
```

## Causa do Problema

Após análise do código, identifiquei que o problema estava na passagem incorreta de props para o componente `SimulationControls` dentro do arquivo `FlowCanvas/index.tsx`.

O componente `SimulationControls` espera receber as seguintes props obrigatórias:
- `onStart`
- `onPause`
- `onRestart`
- `onSpeedChange`
- `onRequestCountChange`
- `onParallelismChange`

No entanto, no arquivo `FlowCanvas/index.tsx`, as props estavam sendo passadas com nomes diferentes:
- `startSimulation` em vez de `onStart`
- `pauseSimulation` em vez de `onPause`
- `restartSimulation` em vez de `onRestart`
- `setSimulationSpeed` em vez de `onSpeedChange`
- `setRequestCount` em vez de `onRequestCountChange`
- `setParallelism` em vez de `onParallelismChange`

Isso causava o erro porque o componente `SimulationControls` tentava chamar funções com nomes que não existiam.

## Solução Aplicada

Corrigi o problema alterando os nomes das props no arquivo `FlowCanvas/index.tsx` para corresponder exatamente aos nomes esperados pelo componente `SimulationControls`.

### Código Original (com erro):

```jsx
<SimulationControls
  isSimulating={isSimulating}
  simulationSpeed={simulationSpeed}
  setSimulationSpeed={setSimulationSpeed}
  startSimulation={startSimulation}
  pauseSimulation={pauseSimulation}
  restartSimulation={restartSimulation}
  requestCount={requestCount}
  setRequestCount={setRequestCount}
  parallelism={parallelism}
  setParallelism={setParallelism}
  nodes={nodes}
  edges={edges}
/>
```

### Código Corrigido:

```jsx
<SimulationControls
  isSimulating={isSimulating}
  simulationSpeed={simulationSpeed}
  onSpeedChange={setSimulationSpeed}
  onStart={startSimulation}
  onPause={pauseSimulation}
  onRestart={restartSimulation}
  requestCount={requestCount}
  onRequestCountChange={setRequestCount}
  parallelism={parallelism}
  onParallelismChange={setParallelism}
  nodes={nodes}
  edges={edges}
/>
```

## Verificação da Correção

Após aplicar a correção, o servidor de desenvolvimento foi iniciado com sucesso e os erros não ocorreram mais. O componente `SimulationControls` agora recebe as funções corretas e pode chamá-las sem gerar erros.

## Recomendações

1. **Consistência de Nomenclatura**: Ao desenvolver componentes React, é importante manter uma nomenclatura consistente para props, especialmente quando se trata de manipuladores de eventos (event handlers). A convenção comum é usar o prefixo "on" para props que são funções de callback.

2. **Validação de Props**: Considere usar PropTypes ou TypeScript para validar as props dos componentes, o que ajudaria a identificar esse tipo de erro durante o desenvolvimento.

3. **Testes Unitários**: Implementar testes unitários para os componentes ajudaria a detectar problemas de interface entre componentes antes que eles cheguem à produção.

## Próximos Passos

O simulador deve funcionar corretamente agora. Para aplicar esta correção ao seu projeto:

1. Abra o arquivo `src/components/FlowCanvas/index.tsx`
2. Localize o trecho onde o componente `SimulationControls` é utilizado
3. Substitua os nomes das props conforme indicado acima
4. Salve o arquivo e reinicie o servidor de desenvolvimento

Se você encontrar outros problemas semelhantes, verifique se os nomes das props correspondem exatamente aos esperados pelos componentes que as recebem.
