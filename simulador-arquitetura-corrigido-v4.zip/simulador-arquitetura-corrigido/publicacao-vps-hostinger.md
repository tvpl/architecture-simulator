# Guia de Publicação do Simulador de Arquitetura em VPS na Hostinger

Este guia fornece instruções detalhadas para publicar o Simulador de Arquitetura em um VPS (Servidor Privado Virtual) na Hostinger, tornando-o acessível pela internet.

## Sumário
1. [Requisitos](#requisitos)
2. [Contratação do VPS na Hostinger](#contratação-do-vps-na-hostinger)
3. [Configuração Inicial do Servidor](#configuração-inicial-do-servidor)
4. [Instalação de Dependências](#instalação-de-dependências)
5. [Configuração do Domínio](#configuração-do-domínio)
6. [Publicação do Simulador](#publicação-do-simulador)
7. [Configuração de HTTPS](#configuração-de-https)
8. [Manutenção e Monitoramento](#manutenção-e-monitoramento)
9. [Solução de Problemas](#solução-de-problemas)

## Requisitos

Antes de começar, certifique-se de ter:

- Uma conta na Hostinger
- Conhecimentos básicos de linha de comando Linux
- O arquivo ZIP do Simulador de Arquitetura (versão mais recente)
- Opcionalmente, um nome de domínio registrado

## Contratação do VPS na Hostinger

1. Acesse [hostinger.com.br](https://www.hostinger.com.br/) e faça login na sua conta
2. Navegue até a seção de VPS e escolha um plano adequado
   - Recomendação mínima: 2GB RAM, 1 vCPU, 20GB SSD
   - Plano recomendado: 4GB RAM, 2 vCPU, 40GB SSD
3. Escolha Ubuntu 22.04 como sistema operacional
4. Complete o processo de compra

## Configuração Inicial do Servidor

Após a ativação do seu VPS, você receberá um e-mail com as credenciais de acesso.

1. Conecte-se ao servidor via SSH:
   ```bash
   ssh root@seu_ip_do_servidor
   ```

2. Atualize o sistema:
   ```bash
   apt update && apt upgrade -y
   ```

3. Configure o fuso horário:
   ```bash
   timedatectl set-timezone America/Sao_Paulo
   ```

4. Crie um usuário não-root para maior segurança:
   ```bash
   adduser simulador
   usermod -aG sudo simulador
   ```

5. Configure o SSH para maior segurança:
   ```bash
   nano /etc/ssh/sshd_config
   ```
   
   Faça as seguintes alterações:
   ```
   PermitRootLogin no
   PasswordAuthentication no
   ```

6. Configure a autenticação por chave SSH:
   ```bash
   mkdir -p /home/simulador/.ssh
   nano /home/simulador/.ssh/authorized_keys
   ```
   
   Cole sua chave pública SSH e salve o arquivo.

7. Defina as permissões corretas:
   ```bash
   chown -R simulador:simulador /home/simulador/.ssh
   chmod 700 /home/simulador/.ssh
   chmod 600 /home/simulador/.ssh/authorized_keys
   ```

8. Reinicie o serviço SSH:
   ```bash
   systemctl restart sshd
   ```

## Instalação de Dependências

1. Instale o Docker e Docker Compose:
   ```bash
   # Instalar dependências
   apt install -y apt-transport-https ca-certificates curl software-properties-common

   # Adicionar chave GPG do Docker
   curl -fsSL https://download.docker.com/linux/ubuntu/gpg | apt-key add -

   # Adicionar repositório do Docker
   add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"

   # Atualizar lista de pacotes
   apt update

   # Instalar Docker
   apt install -y docker-ce docker-ce-cli containerd.io

   # Instalar Docker Compose
   curl -L "https://github.com/docker/compose/releases/download/v2.18.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
   chmod +x /usr/local/bin/docker-compose

   # Adicionar usuário ao grupo docker
   usermod -aG docker simulador
   ```

2. Instale o Nginx para funcionar como proxy reverso:
   ```bash
   apt install -y nginx
   ```

3. Instale o Certbot para certificados SSL:
   ```bash
   apt install -y certbot python3-certbot-nginx
   ```

## Configuração do Domínio

Se você possui um domínio, configure-o para apontar para o IP do seu VPS:

1. Acesse o painel de controle do seu provedor de domínio
2. Adicione um registro A apontando para o IP do seu VPS:
   - Tipo: A
   - Nome: simulador (ou subdomínio desejado)
   - Valor: [IP do seu VPS]
   - TTL: 3600 (ou conforme recomendado pelo provedor)

Se você não possui um domínio, pode usar o IP diretamente ou contratar um domínio na própria Hostinger.

## Publicação do Simulador

1. Conecte-se ao servidor como usuário simulador:
   ```bash
   ssh simulador@seu_ip_do_servidor
   ```

2. Crie um diretório para o projeto:
   ```bash
   mkdir -p ~/simulador-arquitetura
   cd ~/simulador-arquitetura
   ```

3. Faça upload do arquivo ZIP para o servidor (a partir da sua máquina local):
   ```bash
   scp simulador-arquitetura-v5.3.zip simulador@seu_ip_do_servidor:~/simulador-arquitetura/
   ```

4. Descompacte o arquivo no servidor:
   ```bash
   cd ~/simulador-arquitetura
   unzip simulador-arquitetura-v5.3.zip
   ```

5. Inicie o simulador usando Docker Compose:
   ```bash
   cd ~/simulador-arquitetura
   docker-compose up -d
   ```

6. Configure o Nginx como proxy reverso:
   ```bash
   sudo nano /etc/nginx/sites-available/simulador
   ```

   Adicione a seguinte configuração:
   ```nginx
   server {
       listen 80;
       server_name seu_dominio.com.br www.seu_dominio.com.br;
       # Se não tiver domínio, use o IP: server_name seu_ip_do_servidor;

       location / {
           proxy_pass http://localhost:5173;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

7. Ative a configuração do Nginx:
   ```bash
   sudo ln -s /etc/nginx/sites-available/simulador /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```

## Configuração de HTTPS

Se você está usando um domínio, é recomendável configurar HTTPS:

1. Obtenha um certificado SSL com Certbot:
   ```bash
   sudo certbot --nginx -d seu_dominio.com.br -d www.seu_dominio.com.br
   ```

2. Siga as instruções na tela para completar o processo
3. Certbot configurará automaticamente o Nginx para usar HTTPS

## Manutenção e Monitoramento

1. Configure um script para reiniciar o serviço automaticamente:
   ```bash
   nano ~/restart-simulador.sh
   ```

   Adicione o seguinte conteúdo:
   ```bash
   #!/bin/bash
   cd ~/simulador-arquitetura
   docker-compose down
   docker-compose up -d
   ```

   Torne o script executável:
   ```bash
   chmod +x ~/restart-simulador.sh
   ```

2. Configure um cron job para reiniciar o serviço periodicamente (opcional):
   ```bash
   crontab -e
   ```

   Adicione a linha para reiniciar semanalmente:
   ```
   0 3 * * 0 ~/restart-simulador.sh >> ~/restart-log.txt 2>&1
   ```

3. Configure backups regulares:
   ```bash
   mkdir -p ~/backups
   nano ~/backup-simulador.sh
   ```

   Adicione o seguinte conteúdo:
   ```bash
   #!/bin/bash
   TIMESTAMP=$(date +"%Y%m%d-%H%M%S")
   cd ~/simulador-arquitetura
   zip -r ~/backups/simulador-backup-$TIMESTAMP.zip . -x "*/node_modules/*" "*/dist/*"
   # Manter apenas os 5 backups mais recentes
   ls -t ~/backups/simulador-backup-*.zip | tail -n +6 | xargs -r rm
   ```

   Torne o script executável:
   ```bash
   chmod +x ~/backup-simulador.sh
   ```

   Configure um cron job para backups diários:
   ```bash
   crontab -e
   ```

   Adicione a linha:
   ```
   0 2 * * * ~/backup-simulador.sh >> ~/backup-log.txt 2>&1
   ```

## Solução de Problemas

### O simulador não está acessível

1. Verifique se os containers Docker estão rodando:
   ```bash
   docker ps
   ```

2. Verifique os logs do Docker:
   ```bash
   cd ~/simulador-arquitetura
   docker-compose logs
   ```

3. Verifique se o Nginx está rodando:
   ```bash
   sudo systemctl status nginx
   ```

4. Verifique os logs do Nginx:
   ```bash
   sudo tail -f /var/log/nginx/error.log
   ```

5. Verifique se as portas estão abertas:
   ```bash
   sudo ufw status
   ```

   Se o firewall estiver ativo, libere as portas necessárias:
   ```bash
   sudo ufw allow 80/tcp
   sudo ufw allow 443/tcp
   ```

### Atualizando o Simulador

Para atualizar o simulador para uma nova versão:

1. Faça backup da versão atual:
   ```bash
   ~/backup-simulador.sh
   ```

2. Pare os containers:
   ```bash
   cd ~/simulador-arquitetura
   docker-compose down
   ```

3. Faça upload da nova versão e descompacte:
   ```bash
   # A partir da sua máquina local
   scp nova-versao.zip simulador@seu_ip_do_servidor:~/
   
   # No servidor
   cd ~/simulador-arquitetura
   mv ~/nova-versao.zip .
   unzip -o nova-versao.zip
   ```

4. Reinicie os containers:
   ```bash
   docker-compose up -d
   ```

## Conclusão

Seguindo este guia, você terá o Simulador de Arquitetura publicado em um VPS da Hostinger, acessível pela internet, com HTTPS configurado (se estiver usando um domínio) e com rotinas de manutenção e backup.

Para qualquer dúvida adicional, consulte a documentação da Hostinger ou entre em contato com o suporte técnico.
